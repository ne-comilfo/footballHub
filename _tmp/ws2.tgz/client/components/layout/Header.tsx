"use client";

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { Avatar, AvatarBadge, AvatarFallback } from "@/components/ui/avatar";
import { useMe } from "@/hooks/useAuth";
import { initials } from "@/lib/auth/initials";
import ThemeToggle from "../providers/ThemeToggle";
import BurgerMenuPage from "./BurgerMenuPage";

export default function Header() {
  const pathname = usePathname();
  const { data: user } = useMe();
  const links = [
    { href: "/", label: "Football Hub" },
    { href: "/teams", label: "Команды" },
    { href: "/players", label: "Игроки" },
    { href: "/news", label: "Новости" },
    { href: "/about", label: "Обо мне" },
  ];
  return (
    <header className="fixed inset-x-0 top-0 z-50 h-16 bg-background/50 backdrop-blur-md">
      <div className="h-16 flex items-center justify-between px-6 border-b text-xl">
        <nav className="flex flex-row gap-4 md:hidden">
          <BurgerMenuPage />
          <Link href="/" key="/">
            Football Hub
          </Link>
        </nav>
        <nav className="items-center gap-6 hidden md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={
                link.href === "/"
                  ? pathname === "/"
                    ? "text-primary font-semibold"
                    : "text-muted-foreground"
                  : pathname.startsWith(link.href)
                    ? "text-primary font-semibold"
                    : "text-muted-foreground"
              }
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex gap-6 items-center">
          <Tooltip>
            <TooltipTrigger
              render={
                <div>
                  <ThemeToggle />
                </div>
              }
            />

            <TooltipContent side="left">Сменить тему</TooltipContent>
          </Tooltip>
          {user ? (
            <Tooltip>
              <TooltipTrigger
                render={
                  <Link href="/lk" aria-label="Личный кабинет">
                    <Avatar size="lg">
                      <AvatarFallback className="font-semibold">
                        {initials(user.nickname)}
                      </AvatarFallback>
                      <AvatarBadge className="bg-emerald-500" />
                    </Avatar>
                  </Link>
                }
              />
              <TooltipContent side="left">{user.nickname}</TooltipContent>
            </Tooltip>
          ) : (
            <Link href="/auth">Войти</Link>
          )}
        </div>
      </div>
    </header>
  );
}
